##
## This script is sourced by /data/data/dev.anct///files/usr/bin/login before executing shell.
##
