if [ ! -f /data/data/dev.anct///files/home/.config/termux/termux.properties ] && [ ! -e /data/data/dev.anct///files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/dev.anct///files/home/.termux
	cp /data/data/dev.anct///files/usr/share/examples/termux/termux.properties /data/data/dev.anct///files/home/.termux/
fi
